import firebase from "firebase";
require("@firebase/firestore")

const firebaseConfig = {
  apiKey: "AIzaSyCX1-rm0y6D1I0INneBdfPpB1MoWXm-itI",
  authDomain: "biblioteca-virual.firebaseapp.com",
  projectId: "biblioteca-virual",
  storageBucket: "biblioteca-virual.appspot.com",
  messagingSenderId: "613376441867",
  appId: "1:613376441867:web:d39430cf43700e12db910e"
};

firebase.initialize (firebaseConfig); 
export default firebase.firestore();